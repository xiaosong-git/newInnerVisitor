package com.xiaosong.constant;

/**
 * Created by LZ on 2017/6/25.
 */
public class MonitorType {

    /**今日通行情况*/
    public static final int GET_PASSTODAY = 1;
    /**获取人员数量*/
    public static final int GET_PERSONNUM= 2;
    /**今日访客统计*/
    public static final int GET_VISITORSTATTODAY = 3;
    /**周访客统计*/
    public static final int GET_VISITORNUMWEEK= 4;
    /**今日入园统计*/
    public static final int GET_INSTATTODAYBYHOUR = 5;
    /**获取设备状态*/
    public static final int GET_DEVICE_STATUS = 6;
}
