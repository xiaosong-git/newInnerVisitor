package com.xiaosong.util;

public class ThirdResponseObj {

	private String code;
	private String responseEntity;
	public String getCode() {
		return code;
	}
	public void setCode(String code) {
		this.code = code;
	}
	public String getResponseEntity() {
		return responseEntity;
	}
	public void setResponseEntity(String responseEntity) {
		this.responseEntity = responseEntity;
	}
	
	
}
