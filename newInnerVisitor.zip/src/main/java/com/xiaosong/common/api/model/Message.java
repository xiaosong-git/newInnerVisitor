package com.xiaosong.common.api.model;

/**
 * @program: newInnerVisitor
 * @description:
 * @author: cwf
 * @create: 2020-01-28 20:18
 **/
public class Message {
}
