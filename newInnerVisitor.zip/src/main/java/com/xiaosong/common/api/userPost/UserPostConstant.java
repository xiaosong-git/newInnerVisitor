package com.xiaosong.common.api.userPost;

public class UserPostConstant {


    //邀约岗
    public final  static Long YAOYUE_POST = 1l;
    //车辆审批岗
    public final  static Long CAR_POST = 2l;

}
