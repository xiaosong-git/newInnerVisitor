package com.xiaosong.common.api.deptUser;

import com.jfinal.core.Controller;
import com.jfinal.log.Log;

/**
 * @description: 原公司员工，现部门员工
 * @author: cwf
 * @create: 2020-01-10 17:37
 **/
public class DeptUserController extends Controller {
        Log log =Log.getLog(DeptUserController.class);



}
