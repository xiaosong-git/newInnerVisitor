package com.xiaosong.common.visitDevice;

public class RetinueEntity {

    String visitor_name;
    String visitor_phone;
    String visitor_plate;
    String visitor_card_no;
    String visitor_sex;
    String scene_photo;

    public String getVisitor_name() {
        return visitor_name;
    }

    public void setVisitor_name(String visitor_name) {
        this.visitor_name = visitor_name;
    }

    public String getVisitor_phone() {
        return visitor_phone;
    }

    public void setVisitor_phone(String visitor_phone) {
        this.visitor_phone = visitor_phone;
    }

    public String getVisitor_plate() {
        return visitor_plate;
    }

    public void setVisitor_plate(String visitor_plate) {
        this.visitor_plate = visitor_plate;
    }

    public String getVisitor_card_no() {
        return visitor_card_no;
    }

    public void setVisitor_card_no(String visitor_card_no) {
        this.visitor_card_no = visitor_card_no;
    }

    public String getVisitor_sex() {
        return visitor_sex;
    }

    public void setVisitor_sex(String visitor_sex) {
        this.visitor_sex = visitor_sex;
    }

    public String getScene_photo() {
        return scene_photo;
    }

    public void setScene_photo(String scene_photo) {
        this.scene_photo = scene_photo;
    }
}
